Trim_xx_flight.m: It gives trim values for given alpha and gamma.
cmd_trim_wind_xx.m: trim value for climb and calls a function fun_trim_wind_xx
where xx is for climb, level and desent. 
Lin_long.m Linearizes the system gives eigen values .
trim_glideslope.m: gives gamma and velocity for glideslope
cmd_trim_glideslope.m:solves ode and plot is obtained.