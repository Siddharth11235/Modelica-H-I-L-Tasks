This directory contains three InterProcessCommunication libraries. Namely for Linux, Windows and Raspberry Pi, each in its respective directory.
It implements inter process and inter system communication using shared memory and serial communication respectively.
Read UserManual.pdf carefully befor begining.
Follow the instruction given in the manual as well as Tutorials in InterProcessCommunication package.
Each package, function and model has Documentation with it.
Go to InterProcessCommunication > info > Tutorials > GettingStarted for beinners tutorial and Advanced for modifying and using the package.

License: GNU GPL 2017
This is a free program, and you are welcome to modify and redistribute it. This program comes with ABSOLUTELY NO WARRANTY.
Credits: ModeliCon Infotech Team 
Sushmita (Intern)
Namrata (Intern)
Ankur Gajjar 
Shubham Patne 
Jal Panchal 
Ritesh Sharma 
Pavan P 
