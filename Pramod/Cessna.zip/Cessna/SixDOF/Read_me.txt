Trim_body.m: for a given value of gamma and alpha, it trims the flight.
cmd_sixdof_pert_long_lateral.m: Gives complete Sixdof simulation for trim values with disturbances.
cmd_sixdof.m: Gives complete Sixdof simulation for trim values without disturbances.
cmd_body_sixdof.m: It is not complete. Intention is to simulate sixdof in body axis.